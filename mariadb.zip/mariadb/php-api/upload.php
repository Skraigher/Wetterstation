<?php
$servername = "mariadb";
$username = "root";
$password = "sebi";
$dbname = "wetterstation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$temp = isset($_POST['temperatur']) ? floatval($_POST['temperatur']) : null;
$luftfeuchtigkeit = isset($_POST['luftfeuchtigkeit']) ? floatval($_POST['luftfeuchtigkeit']) : null;
$sensor = isset($_POST['sensor']) ? floatval($_POST['sensor']) : null;

if ($temp === null || $luftfeuchtigkeit === null || $sensor === null) {
    http_response_code(400);
    echo json_encode(["error" => "Missing parameters"]);
    exit;
}

// Insert mit automatischem timestamp
$stmt = $conn->prepare("INSERT INTO messdaten (temperatur, luftfeuchtigkeit, sensor) VALUES (?, ?, ?)");
$stmt->bind_param("ddd", $temp, $luftfeuchtigkeit, $sensor);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Database error"]);
}

$stmt->close();
$conn->close();
?>
