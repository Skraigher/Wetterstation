<?php
$servername = "mariadb";
$username = "root";
$password = "sebi";
$dbname = "wetterstation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, temperatur, luftfeuchtigkeit, sensor, timestamp FROM messdaten ORDER BY timestamp DESC LIMIT 20"; // letzte 20 Einträge
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Temperatur (°C)</th><th>Luftfeuchtigkeit (%)</th><th>Sensorwert</th><th>Zeitstempel</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"]. "</td>";
        echo "<td>" . $row["temperatur"]. "</td>";
        echo "<td>" . $row["luftfeuchtigkeit"]. "</td>";
        echo "<td>" . $row["sensor"]. "</td>";
        echo "<td>" . $row["timestamp"]. "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Keine Daten gefunden.";
}

$conn->close();
?>
